import React from 'react';

import TweetList from '../../components/TweetList';

const AllTweetsPage = (properties) => {
    return (
        <div>
            <TweetList />
        </div>
    );
};

export default AllTweetsPage;
