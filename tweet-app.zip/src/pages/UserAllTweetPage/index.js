import React from 'react';

const UserAllTweetPage = (properties) => {

    
    return (
        <div>
            
        </div>
    );
};

export default UserAllTweetPage;
