import React from 'react';
import RegistrationForm from '../../components/RegisterForm';

const RegistrationPage = (properties) => {
    return (
        <div>
            <RegistrationForm />
        </div>
    );
};

export default RegistrationPage;
