import React from 'react';

const LoadingRedirect = (properties) => {

    React.useEffect(()=> {

    },[]);

    return (
        <div className="card">
           <p> Loading... </p>
        </div>
    )
}

export default LoadingRedirect;
