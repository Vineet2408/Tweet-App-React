import React from 'react';

import UserList from '../../components/UserList'

const AllUserPage = (properties) => {
    return (
        <div>
            <UserList ></UserList>
        </div>
    );
};

export default AllUserPage;
