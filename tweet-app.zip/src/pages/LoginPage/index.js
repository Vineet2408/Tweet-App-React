import React from 'react';
import LoginForm from '../../components/LoginForm';

const LoginPage = (properties) => {
    
    return (
        <div>
            <LoginForm />
        </div>
    );
};

export default LoginPage;
