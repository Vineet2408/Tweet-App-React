export const profilePicSize = {
    16:'size-16',
    32:'size-32',
    64:'size-64',
    128:'size-128',
    256:'size-256',
}